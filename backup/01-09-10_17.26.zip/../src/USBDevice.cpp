/*
 * USBDevice.cpp
 *
 *  Created on: Sep 1, 2010
 *      Author: jordan
 */

