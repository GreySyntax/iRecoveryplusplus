/*
 * Program.cpp
 *
 *  Created on: Sep 1, 2010
 *      Author: jordan
 */
#include <iostream>

using namespace std;

int main(int argc, char *argv[]) {

	cout << "iRecovery++  Copyright (C) 2010  GreySyntax\r\n";
	cout << "This program comes with ABSOLUTELY NO WARRANTY; for details `./iRecovery -w'.\r\n";
	cout << "This is free software, and you are welcome to redistribute it\r\n";
	cout << "under certain conditions; type `./iRecovery -o' for details.\r\n" << endl;

	return 1;
}
